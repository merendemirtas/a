#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// Created by Ilkin Kala, Eren Demirtas and  for Algoritma ve Programlamaya Giris //

struct BankAccount {
    char accountNumber[20];
    char accountHolder[100];
    double balance;
};

int signIn(struct BankAccount *account) {
    char accountNumber[20];
    printf("Enter Account Number: ");
    scanf("%s", accountNumber);

    FILE *file = fopen("accounts.txt", "r");
    if (file == NULL) {
        printf("Error opening file for reading.\n");
        exit(1);
    }

    int userFound = 0;

    while (fscanf(file, "%s %s %lf", account->accountNumber, account->accountHolder, &account->balance) == 3) {
        if (strcmp(account->accountNumber, accountNumber) == 0) {
            userFound = 1;
            break;
        }
    }

    fclose(file);

    return userFound;
}


void saveAccountToFile(struct BankAccount account) {
    FILE *file = fopen("accounts.txt", "r");
    if (file == NULL) {
        printf("Error opening file for reading.\n");
        exit(1);
    }

    int accountFound = 0;
    struct BankAccount currentAccount;

    // Open a temporary file for writing
    FILE *tempFile = fopen("temp.txt", "w");
    if (tempFile == NULL) {
        printf("Error opening temporary file for writing.\n");
        fclose(file);
        exit(1);
    }

    // Search for the account number in the file
    while (fscanf(file, "%s %s %lf", currentAccount.accountNumber, currentAccount.accountHolder, &currentAccount.balance) == 3) {
        if (strcmp(currentAccount.accountNumber, account.accountNumber) == 0) {
            // Update the existing entry
            fprintf(tempFile, "%s %s %.2f\n", account.accountNumber, account.accountHolder, account.balance);
            accountFound = 1;
        } else {
            // Copy other entries as is
            fprintf(tempFile, "%s %s %.2f\n", currentAccount.accountNumber, currentAccount.accountHolder, currentAccount.balance);
        }
    }

    // If the account number is not found, append a new entry
    if (!accountFound) {
        fprintf(tempFile, "%s %s %.2f\n", account.accountNumber, account.accountHolder, account.balance);
    }

    fclose(file);
    fclose(tempFile);

    // Replace the original file with the temporary file
    remove("accounts.txt");
    rename("temp.txt", "accounts.txt");
}

void displayAccountInfo(struct BankAccount account) {
    printf("\nAccount Information:\n");
    printf("Account Number: %s\n", account.accountNumber);
    printf("Account Holder: %s\n", account.accountHolder);
    printf("Balance: $%.2f\n", account.balance);
}

void deposit(struct BankAccount *account, double amount) {
    account->balance += amount;
    printf("Deposit successful. New balance: $%.2f\n", account->balance);

    // Save the updated account information to the file
    saveAccountToFile(*account);
}

void withdraw(struct BankAccount *account, double amount) {
    if (amount > account->balance) {
        printf("Insufficient funds. Withdrawal unsuccessful.\n");
    } else {
        account->balance -= amount;
        printf("Withdrawal successful. New balance: $%.2f\n", account->balance);

        // Save the updated account information to the file
        saveAccountToFile(*account);
    }
}

void deleteAccount(char *accountNumber) {
    FILE *file = fopen("accounts.txt", "r");
    if (file == NULL) {
        printf("Error opening file for reading.\n");
        exit(1);
    }

    // Create a temporary file
    FILE *tempFile = fopen("temp.txt", "w");
    if (tempFile == NULL) {
        printf("Error opening temporary file for writing.\n");
        exit(1);
    }

    struct BankAccount currentAccount;

    // Copy all accounts to the temporary file except the one to be deleted
    while (fscanf(file, "%s %s %lf", currentAccount.accountNumber, currentAccount.accountHolder, &currentAccount.balance) == 3) {
        if (strcmp(currentAccount.accountNumber, accountNumber) != 0) {
            fprintf(tempFile, "%s %s %.2f\n", currentAccount.accountNumber, currentAccount.accountHolder, currentAccount.balance);
        }
    }

    fclose(file);
    fclose(tempFile);

    // Replace the original file with the temporary file
    remove("accounts.txt");
    rename("temp.txt", "accounts.txt");

    printf("Account deleted successfully!\n");
}

void signUp() {
    struct BankAccount newAccount;

    printf("Enter Account Number: ");
    scanf("%s", newAccount.accountNumber);

    printf("Enter Account Holder Name: ");
    scanf("%s", newAccount.accountHolder);

    printf("Enter Initial Balance: ");
    scanf("%lf", &newAccount.balance);

    // Open file in append mode and write account details
    FILE *file = fopen("accounts.txt", "r+");
    if (file == NULL) {
        perror("Error opening file");
        exit(1);
    }

    fprintf(file, "%s %s %.2f\n", newAccount.accountNumber, newAccount.accountHolder, newAccount.balance);
    fclose(file);

    printf("Account created successfully!\n");
}

int main() {
    char choice;
    struct BankAccount loggedInAccount;

    do {
        printf("\nMain Menu:\n");
        printf("1 - Sign Up\n");
        printf("2 - Sign In\n");
        printf("Q - Quit\n");
        printf("Enter choice: ");
        scanf(" %c", &choice);

        switch (choice) {
            case '1':
                signUp();
                break;

            case '2':
                if (signIn(&loggedInAccount)) {
                    printf("\nWelcome, %s!\n", loggedInAccount.accountHolder);

                    do {
                        printf("\nUser Menu:\n");
                        printf("D - Deposit\n");
                        printf("W - Withdraw\n");
                        printf("B - Check Balance\n");
                        printf("X - Delete Account\n");
                        printf("Q - Quit\n");
                        printf("Enter choice: ");
                        scanf(" %c", &choice);

                        switch (choice) {
                            case 'D':
                            case 'd':
                                printf("Enter deposit amount: ");
                                double depositAmount;
                                scanf("%lf", &depositAmount);
                                deposit(&loggedInAccount, depositAmount);
                                break;

                            case 'W':
                            case 'w':
                                printf("Enter withdrawal amount: ");
                                double withdrawalAmount;
                                scanf("%lf", &withdrawalAmount);
                                withdraw(&loggedInAccount, withdrawalAmount);
                                break;

                            case 'B':
                            case 'b':
                                displayAccountInfo(loggedInAccount);
                                break;

                            case 'X':
                            case 'x':
                                deleteAccount(loggedInAccount.accountNumber);
                                printf("Logging out.\n");
                                break;

                            case 'Q':
                            case 'q':
                                printf("Logging out.\n");
                                break;

                            default:
                                printf("Invalid choice. Please try again.\n");
                                break;
                        }
                    } while (choice != 'Q' && choice != 'q');

                } else {
                    printf("User not found.\n");
                }
                break;

            case 'Q':
            case 'q':
                printf("Exiting program.\n");
                break;

            default:
                printf("Invalid choice. Please try again.\n");
                break;
        }

    } while (choice != 'Q' && choice != 'q');

    return 0;
}
